#!/usr/bin/env bash
. git-hyper-blame.demo.common.sh
run git blame ipsum.txt
